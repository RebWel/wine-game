from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import random
import csv
import json
from otree.models_concrete import ParticipantToPlayerLookup, RoomToSession
from otree.models.session import Session as BaseSession


author = 'Your name here'

doc = """
Your app description
"""

class Constants(BaseConstants):
    name_in_url = 'Experiment'
    players_per_group = None
    num_rounds = 1

class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    sequence_of_apps = models.LongStringField()

    aim = models.IntegerField(
        label="What should you aim for in this game?",
        choices=[
            [1, 'Attend to other obligations on my schedule'],
            [2, 'Achieve high forecast accuracy of the wine demand'],
            [3, 'Finish first'],
        ],
        widget=widgets.RadioSelect,
    )

    mechanism = models.IntegerField(
        label="How is the model forecast generated?",
        choices=[
            [1, 'statistical method based on historical data, calendar entries and public sources'],
            [2, 'statistical method based on future sales data'],
            [3, 'human expert predictions']
        ],
        widget=widgets.RadioSelect,
    )

    accuracy = models.IntegerField(
        label="When can you decide whether you stay with the algorithm forecast or go with your own?",
        choices=[
            [1,'After several information about the celebration conditions but before the proposal of the algorithm'],
            [2,'Before the game starts'],
            [3,'After several information about the celebration conditions and the proposal of the algorithm'],
            [4,'The algorithm decides if I stay with the forecast or not']
        ],
        widget=widgets.RadioSelect,
    )

    def role(self):
        if self.id_in_group % 3 == 0:
            return 'treatment'
        elif self.id_in_group % 3 == 1:
            return 'treatment2'
        else:
            return 'control'