from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
from . import models
from ._builtin import Page, WaitPage
import json
import random
from random import sample, choice
from itertools import groupby
from otree.models_concrete import ParticipantToPlayerLookup, RoomToSession
from otree.common_internal import (
    random_chars_8, random_chars_10, get_admin_secret_code, get_app_label_from_name
)
import otree.common_internal
from django.core.urlresolvers import reverse

class Welcome(Page):
    pass

class Instructions(Page):
    pass


class Understanding1(Page):
    form_model = 'player'
    form_fields = ['aim']
    def aim_error_message(self, choice):
        if choice != 2:
            return 'Please study the instructions carefully and enter a valid answer.'

class Understanding2(Page):
    form_model = 'player'
    form_fields = ['mechanism']
    def mechanism_error_message(self, choice):
        if choice != 1:
            return 'Please study the instructions below carefully and enter a valid answer.'

class Understanding3(Page):
    form_model = 'player'
    form_fields = ['accuracy']
    def accuracy_error_message(self, choice):
        if choice != 3:
            return 'Please study the instructions below carefully and enter a valid answer'


class Wait(Page):
    pass

page_sequence = [
    Welcome,
    Instructions,
    Understanding1,
    Understanding2,
    Understanding3,
    Wait,
]
