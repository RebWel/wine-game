from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
from . import models
from ._builtin import Page, WaitPage
import json
import random
from random import sample, choice
from itertools import groupby
from otree.models_concrete import ParticipantToPlayerLookup, RoomToSession
from otree.common_internal import (
    random_chars_8, random_chars_10, get_admin_secret_code, get_app_label_from_name
)
import otree.common_internal
from django.core.urlresolvers import reverse
from radiogrid import RadioGridField

class InstructionsInsert1(Page):
    pass

class InstructionsInsert2(Page):
    pass

class InstructionsInsert3(Page):
    pass



class Risk (Page):
    def is_displayed(self):
        return self.player.role() == 'treatment'

    form_model = 'player'
    form_fields = ['Risk']



class Buttoncontrol (Page):
    def is_displayed(self):
        if 'treatment2' in self.player.role():
            return False
        if self.player.role() == 'admin':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast1']


class Buttoncontrol2 (Page):
    def is_displayed(self):
        if 'treatment2' in self.player.role():
            return False
        if self.player.role() == 'admin':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast2']


class Buttoncontrol3 (Page):
    def is_displayed(self):
        if 'treatment2' in self.player.role():
            return False
        if self.player.role() == 'admin':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast3']


class Chatbot (Page):
    def is_displayed(self):
        if self.player.role() == 'treatment':
            return False
        if self.player.role() == 'control':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast1']


class Chatbot2 (Page):
    def is_displayed(self):
        if self.player.role() == 'treatment':
            return False
        if self.player.role() == 'control':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast2']



class Chatbot3 (Page):
    def is_displayed(self):
        if self.player.role() == 'treatment':
            return False
        if self.player.role() == 'control':
            return False
        return True

    form_model = 'player'
    form_fields = ['Buttonforecast3']



class Fillinboxcontrol1(Page):
    def is_displayed(self):
        return self.player.Buttonforecast1 == 1

    form_model = 'player'
    form_fields = ['Fillinboxcontrol1a1', 'Fillinboxcontrol1b1', 'Fillinboxcontrol2a1', 'Fillinboxcontrol2b1',
                   'Fillinboxcontrol3a1', 'Fillinboxcontrol3b1', 'Fillinboxcontrol4a1', 'Fillinboxcontrol4b1']

    def error_message(self, values):
        print('values is', values)
        if values["Fillinboxcontrol1a1"] + values["Fillinboxcontrol1b1"] != 100:
            return 'Please ensure that the percentage of red and white wine, sum to 100.'
        elif values["Fillinboxcontrol3a1"] == 4 and values["Fillinboxcontrol3b1"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (storage).'
        elif values["Fillinboxcontrol2a1"] == 4 and values["Fillinboxcontrol2b1"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (size).'
        elif values["Fillinboxcontrol2a1"] == 4 and values["Fillinboxcontrol3a1"] != 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b1"] == 4 and values["Fillinboxcontrol3b1"] != 4:
            return 'Please think about if you want to forecast white wine or not.'
        elif values["Fillinboxcontrol2a1"] != 4 and values["Fillinboxcontrol3a1"] == 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b1"] != 4 and values["Fillinboxcontrol3b1"] == 4:
            return 'Please think about if you want to forecast white wine or not.'
    #    elif ((values["Fillinboxcontrol4a1"]*100)/(values["Fillinboxcontrol4a1"]+values["Fillinboxcontrol4b1"])) != values["Fillinboxcontrol1a1"]:
     #       return 'Please check your amount of wine with your percentage of wine you entered.'
      #  elif ((values["Fillinboxcontrol4b1"]*100)/(values["Fillinboxcontrol4a1"]+values["Fillinboxcontrol4b1"])) != values["Fillinboxcontrol1b1"]:
      #      return 'Please check your amount of wine with your percentage of wine you entered.'
        elif values["Fillinboxcontrol2a1"] == 4 and values["Fillinboxcontrol4a1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b1"] == 4 and values["Fillinboxcontrol4b1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a1"] == 4 and values["Fillinboxcontrol4a1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b1"] == 4 and values["Fillinboxcontrol4b1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2a1"] == 4 and values["Fillinboxcontrol1a1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b1"] == 4 and values["Fillinboxcontrol1b1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a1"] == 4 and values["Fillinboxcontrol1a1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b1"] == 4 and values["Fillinboxcontrol1b1"] > 0:
            return 'Please think about if you want to forecast red wine or not.'


class Fillinboxcontrol2(Page):
    def is_displayed(self):
        return self.player.Buttonforecast2 == 1

    form_model = 'player'
    form_fields = ['Fillinboxcontrol1a2', 'Fillinboxcontrol1b2', 'Fillinboxcontrol2a2', 'Fillinboxcontrol2b2',
                   'Fillinboxcontrol3a2', 'Fillinboxcontrol3b2', 'Fillinboxcontrol4a2', 'Fillinboxcontrol4b2']

    def error_message(self, values):
        print('values is', values)
        if values["Fillinboxcontrol1a2"] + values["Fillinboxcontrol1b2"] != 100:
            return 'Please ensure that the percentage of red and white wine, sum to 100.'
        elif values["Fillinboxcontrol3a2"] == 4 and values["Fillinboxcontrol3b2"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (storage).'
        elif values["Fillinboxcontrol2a2"] == 4 and values["Fillinboxcontrol2b2"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (size).'
        elif values["Fillinboxcontrol2a2"] == 4 and values["Fillinboxcontrol3a2"] != 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b2"] == 4 and values["Fillinboxcontrol3b2"] != 4:
            return 'Please think about if you want to forecast white wine or not.'
        elif values["Fillinboxcontrol2a2"] != 4 and values["Fillinboxcontrol3a2"] == 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b2"] != 4 and values["Fillinboxcontrol3b2"] == 4:
            return 'Please think about if you want to forecast white wine or not.'
     #   elif ((values["Fillinboxcontrol4a2"]*100)/(values["Fillinboxcontrol4a2"]+values["Fillinboxcontrol4b2"])) != values["Fillinboxcontrol1a2"]:
     #       return 'Please check your amount of wine with your percentage of wine you entered.'
     #   elif ((values["Fillinboxcontrol4b2"]*100)/(values["Fillinboxcontrol4a2"]+values["Fillinboxcontrol4b2"])) != values["Fillinboxcontrol1b2"]:
     #       return 'Please check your amount of wine with your percentage of wine you entered.'
        elif values["Fillinboxcontrol2a2"] == 4 and values["Fillinboxcontrol4a2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b2"] == 4 and values["Fillinboxcontrol4b2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a2"] == 4 and values["Fillinboxcontrol4a2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b2"] == 4 and values["Fillinboxcontrol4b2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2a2"] == 4 and values["Fillinboxcontrol1a2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b2"] == 4 and values["Fillinboxcontrol1b2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a2"] == 4 and values["Fillinboxcontrol1a2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b2"] == 4 and values["Fillinboxcontrol1b2"] > 0:
            return 'Please think about if you want to forecast red wine or not.'




class Fillinboxcontrol3(Page):
    def is_displayed(self):
        return self.player.Buttonforecast3 == 1

    form_model = 'player'
    form_fields = ['Fillinboxcontrol1a3', 'Fillinboxcontrol1b3', 'Fillinboxcontrol2a3', 'Fillinboxcontrol2b3',
                   'Fillinboxcontrol3a3', 'Fillinboxcontrol3b3', 'Fillinboxcontrol4a3', 'Fillinboxcontrol4b3']

    def error_message(self, values):
        print('values is', values)
        if values["Fillinboxcontrol1a3"] + values["Fillinboxcontrol1b3"] != 100:
            return 'Please ensure that the percentage of red and white wine, sum to 100.'
        elif values["Fillinboxcontrol3a3"] == 4 and values["Fillinboxcontrol3b3"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (storage).'
        elif values["Fillinboxcontrol2a3"] == 4 and values["Fillinboxcontrol2b3"] == 4:
            return 'Please ensure that you forecast at least one kind of wine (size).'
        elif values["Fillinboxcontrol2a3"] == 4 and values["Fillinboxcontrol3a3"] != 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b3"] == 4 and values["Fillinboxcontrol3b3"] != 4:
            return 'Please think about if you want to forecast white wine or not.'
        elif values["Fillinboxcontrol2a3"] != 4 and values["Fillinboxcontrol3a3"] == 4:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b3"] != 4 and values["Fillinboxcontrol3b3"] == 4:
            return 'Please think about if you want to forecast white wine or not.'
     #   elif ((values["Fillinboxcontrol4a3"]*100)/(values["Fillinboxcontrol4a3"]+values["Fillinboxcontrol4b3"])) != values["Fillinboxcontrol1a3"]:
     #       return 'Please check your amount of wine with your percentage of wine you entered.'
     #   elif ((values["Fillinboxcontrol4b3"]*100)/(values["Fillinboxcontrol4a3"]+values["Fillinboxcontrol4b3"])) != values["Fillinboxcontrol1b3"]:
     #       return 'Please check your amount of wine with your percentage of wine you entered.'
        elif values["Fillinboxcontrol2a3"] == 4 and values["Fillinboxcontrol4a3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b3"] == 4 and values["Fillinboxcontrol4b3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a3"] == 4 and values["Fillinboxcontrol4a3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b3"] == 4 and values["Fillinboxcontrol4b3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2a3"] == 4 and values["Fillinboxcontrol1a3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol2b3"] == 4 and values["Fillinboxcontrol1b3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3a3"] == 4 and values["Fillinboxcontrol1a3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'
        elif values["Fillinboxcontrol3b3"] == 4 and values["Fillinboxcontrol1b3"] > 0:
            return 'Please think about if you want to forecast red wine or not.'



page_sequence = [
    InstructionsInsert1,
    Risk,
    Buttoncontrol,
    Chatbot,
    Fillinboxcontrol1,

    InstructionsInsert2,
    Risk,
    Buttoncontrol2,
    Chatbot2,
    Fillinboxcontrol2,

    InstructionsInsert3,
    Risk,
    Buttoncontrol3,
    Chatbot3,
    Fillinboxcontrol3,
    ]
