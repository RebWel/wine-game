from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import random
import csv
import json
from otree.models_concrete import ParticipantToPlayerLookup, RoomToSession
from otree.models.session import Session as BaseSession
from radiogrid import RadioGridField

author = 'Your name here'

doc = """
Your app description
"""

class Constants(BaseConstants):
    name_in_url = 'GameExperiment'
    players_per_group = None
    num_rounds = 1

    instructionsInsert1_template = 'Real/InstructionsInsert1.html'
    instructionsInsert2_template = 'Real/InstructionsInsert2.html'
    instructionsInsert3_template = 'Real/InstructionsInsert3.html'

class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    sequence_of_apps = models.LongStringField()

    Risk = models.IntegerField(
        label="What preference suits you more?",
        choices=[
            [1, 'narrow planning'],
            [2, 'normal calculation'],
            [3, 'safety stock'],
        ],
        widget=widgets.RadioSelect
    )


    Buttonforecast1 = models.IntegerField(
        label="Do you want to stay with the model forecast?",
        choices=[
            [1, 'No'],
            [2, 'Yes'],
        ],
        widget=widgets.RadioSelect
    )

    Buttonforecast2 = models.IntegerField(
        label="Do you want to stay with the model forecast?",
        choices=[
            [1, 'No'],
            [2, 'Yes'],
        ],
        widget=widgets.RadioSelect
    )

    Buttonforecast3 = models.IntegerField(
        label="Do you want to stay with the model forecast?",
        choices=[
            [1, 'No'],
            [2, 'Yes'],
        ],
        widget=widgets.RadioSelect
    )

    Fillinboxcontrol1a1 = models.FloatField(
        label="How much red wine do you need (in %)? ",
        min=0.0, max=100.0
    )

    Fillinboxcontrol1b1 = models.FloatField(
        label="How much white wine do you need (in %)? ",
        min=0.0, max=100.0
    )

    Fillinboxcontrol2a1 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No red wine'],
        ],
        label="Which size of red wine should you order? ",
        widget = widgets.RadioSelect,
    )

    Fillinboxcontrol2b1 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No white wine'],
        ],
        label="Which size of white wine should you order? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol3a1 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No red wine'],
        ],
        label="Where should you store your red wine? ",
        widget = widgets.RadioSelect,
    )


    Fillinboxcontrol3b1 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No white wine'],
        ],
        label="Where should you store your white wine? ",
        widget = widgets.RadioSelect,
    )

    Fillinboxcontrol4a1 = models.FloatField(
        label="How much red wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    Fillinboxcontrol4b1 = models.FloatField(
        label="How much white wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    Fillinboxcontrol1a2 = models.FloatField(
        label="How much red wine do you need (in %)? ",
        min=0.0, max=100.0
    )

    Fillinboxcontrol1b2 = models.FloatField(
        label="How much white wine do you need (in %)? ",
        min=0.0, max=100.0
    )

    Fillinboxcontrol2a2 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No red wine'],
        ],
        label="Which size of red wine should you order? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol2b2 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No white wine'],
        ],
        label="Which size of white wine should you order? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol3a2 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No red wine'],
        ],
        label="Where should you store your red wine? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol3b2 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No white wine'],
        ],
        label="Where should you store your white wine? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol4a2 = models.FloatField(
        label="How much red wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    Fillinboxcontrol4b2 = models.FloatField(
        label="How much white wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    Fillinboxcontrol1a3 = models.FloatField(
        label="How much red wine do you need (in %)? ",
        min=0, max=100
    )

    Fillinboxcontrol1b3 = models.FloatField(
        label="How much white wine do you need (in %)? ",
        min=0, max=100
    )

    Fillinboxcontrol2a3 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No red wine'],
        ],
        label="Which size of red wine should you order? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol2b3 = models.IntegerField(
        choices=[
            [1, 'Barrel'],
            [2, 'Boxes'],
            [3, 'Bottles'],
            [4, 'No white wine'],
        ],
        label="Which size of white wine should you order? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol3a3 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No red wine'],
        ],
        label="Where should you store your red wine? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol3b3 = models.IntegerField(
        choices=[
            [1, 'Pantry'],
            [2, 'Kitchen'],
            [3, 'Fridge'],
            [4, 'No white wine'],
        ],
        label="Where should you store your white wine? ",
        widget=widgets.RadioSelect,
    )

    Fillinboxcontrol4a3 = models.FloatField(
        label="How much red wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    Fillinboxcontrol4b3 = models.FloatField(
        label="How much white wine do you need (in l)? ",
        min=0.0, max=1000.0
    )

    def chat_nickname(self):
        if self.role() == 'admin':
            return 'Algorithm'
        return 'Player {}'.format(self.id_in_group)

    def chat_configs(self):
        configs = []
        if self.role() == 'admin':
            for other in self.get_others_in_group():
                if other.role() == 'treatment2':
                    if other.id_in_group < self.id_in_group:
                        lower_id, higher_id = other.id_in_group, self.id_in_group
                    else:
                        lower_id, higher_id = self.id_in_group, other.id_in_group
                    configs.append({
                        # make a name for the channel that is the same for all
                        # channel members. That's why we order it (lower, higher)
                        'channel': '{}-{}-{}'.format(self.group.id, lower_id, higher_id),
                        'label': 'Chat with {}'.format(other.chat_nickname())
                    })
        elif self.role() == 'treatment2':
            configs.append({'channel':'{}-1-{}'.format(self.group.id, self.id_in_group),
                            'label':'Chat with Algorithm'})
        return configs



    def role(self):
        if self.id_in_group == 1:
            return 'admin'
        elif self.id_in_group % 3 == 0:
            return 'treatment'
        elif self.id_in_group % 3 == 1:
            return 'treatment2'
        else:
            return 'control'
